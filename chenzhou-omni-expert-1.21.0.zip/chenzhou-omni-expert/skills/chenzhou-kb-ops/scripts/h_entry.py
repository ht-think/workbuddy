#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""h_entry.py — WorkBuddy 入口自动判定（零依赖，供接入通道自动决策用）。

判定逻辑（每会话需要查库时跑一次，结果本会话内复用）：
- 桌面客户端强信号（本机安装路径 / 本地命名管道 IPC）任一存在 → "desktop"
- 全部缺失 → 视为网页版沙箱 → "web"

输出：单行 JSON：{"entry": "desktop"|"web", "signals": [命中的环境变量名]}
退出码：0 正常；2 运行环境异常（无 os.environ 等，理论不可达）。
"""
import json
import os
import sys

DESKTOP_SIGNALS = (
    "WORKBUDDY_RESOURCES_PATH",
    "CODEBUDDY_DOCUMENT_IPC_ADDRESS",
)


def main() -> int:
    signals = [k for k in DESKTOP_SIGNALS if os.environ.get(k)]
    entry = "desktop" if signals else "web"
    print(json.dumps({"entry": entry, "signals": signals}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
