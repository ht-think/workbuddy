#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""郴州全域知识专家 · 生成自建离线知识层（make_offline_kb.py）

这是什么
    只读读取 ht_library.sqlite（瀚天知识库对外知识单元层），生成**本资产自建**的
    离线知识层：域—专题—单元标题 三级索引 ＋ 分布统计，输出为 Markdown 分片，
    供「知识库通道」（公网连接器 / 包内只读快照）均不可用时做**导航与概览**。
    ※ v1.8.0：本机实时库通道已移除——须显式 --db 传源库路径；常规重建将改由公网连接器执行。

三条硬约束
    1. **零正文照录**：本层只含域/专题/单元标题索引，**不含任何单元 content 片段**，**不含规模数字与分布统计**（合规口径）。
    2. **内部材料**：本层形态是内部索引，**不得原样输出给用户**；对外仍走原创整合。
    3. **独立自建**：与「瀚天智库」的离线知识档（kb/）无任何关系——来源、命名、结构、
       条目口径全部不同；本文件及其产物均为本资产专有。

用法
    python make_offline_kb.py [--db <ht_library.sqlite>] [--out <输出目录>]

默认
    库：由 --db 显式指定（不再支持环境变量默认源）
    输出：<包根>/assets/offline_kb/
"""

import argparse
import json
import os
import sqlite3
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
PKG_ROOT = BASE.parents[2]
DEFAULT_OUT = PKG_ROOT / "assets" / "offline_kb"

KIND_LABEL = {
    "fact": "事实", "chronology": "纪事", "narrative": "记述", "list": "名录",
    "table": "表册", "verse": "韵文", "bio": "小传",
}
NATURE_LABEL = {
    "documentary": "文献", "quasi_documentary": "准文献",
    "folklore": "民间文艺", "literary": "文学",
}
CHANNEL_LABEL = {"doc": "文献", "web": "网络", "both": "文献+网络"}


def ro(db):
    return sqlite3.connect("file:%s?mode=ro" % str(db).replace("\\", "/"), uri=True)


def fmt_counter(counter, labels=None, top=None):
    if not counter:
        return "—"
    items = counter.most_common(top) if top else sorted(counter.items(), key=lambda x: -x[1])
    out = []
    for k, v in items:
        k = labels.get(k, k) if labels else k
        out.append("%s %d" % (k, v))
    return "｜".join(out)


def era_span(rows):
    frs = [r["era_from"] for r in rows if (r["era_from"] or "").strip()]
    tos = [r["era_to"] for r in rows if (r["era_to"] or "").strip()]
    if not frs and not tos:
        return "—"
    lo = min(frs) if frs else "?"
    hi = max(tos) if tos else (max(frs) if frs else "?")
    return "%s ~ %s" % (lo, hi)


def main():
    ap = argparse.ArgumentParser(description="生成自建离线知识层")
    ap.add_argument("--db", required=True,
                    help="源库路径（显式指定；不再支持环境变量默认源）")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    a = ap.parse_args()

    db, out = Path(a.db), Path(a.out)
    if not db.exists():
        sys.exit("❌ 库不存在：%s" % db)
    out.mkdir(parents=True, exist_ok=True)

    con = ro(db)
    con.row_factory = sqlite3.Row
    stamp = datetime.now().strftime("%Y-%m-%d")
    stamp_full = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    domains = con.execute("select domain_id,name,ordinal from domains order by ordinal").fetchall()
    topics = con.execute(
        "select topic_id,domain_id,name,scope_note,status,unit_count,source_channel from topics order by topic_id"
    ).fetchall()
    units = con.execute(
        "select unit_id,topic_id,unit_title,kind,source_nature,source_channel,"
        "era_from,era_to,era_precision,place,chars from units order by topic_id,unit_id"
    ).fetchall()
    aliases = {}
    for r in con.execute("select topic_id,alias from topic_aliases order by topic_id,weight desc"):
        aliases.setdefault(r["topic_id"], []).append(r["alias"])

    by_topic = {}
    for u in units:
        by_topic.setdefault(u["topic_id"], []).append(u)
    topics_by_domain = {}
    for t in topics:
        topics_by_domain.setdefault(t["domain_id"], []).append(t)

    total_units = len(units)
    total_chars = sum((u["chars"] or 0) for u in units)

    # ---------- 分片文件 ----------
    files = []
    index_rows = []
    for d in domains:
        dts = topics_by_domain.get(d["domain_id"], [])
        dus = [u for t in dts for u in by_topic.get(t["topic_id"], [])]
        kind_c = Counter(u["kind"] for u in dus)
        nat_c = Counter(u["source_nature"] for u in dus)
        chn_c = Counter(u["source_channel"] for u in dus)
        place_c = Counter((u["place"] or "").strip() for u in dus if (u["place"] or "").strip())
        unknown = sum(1 for u in dus if (u["era_precision"] or "") == "unknown")
        dchars = sum((u["chars"] or 0) for u in dus)

        slug = "%02d-%s" % (d["ordinal"], d["domain_id"].replace("HT-", "").lower())
        fname = "%s.md" % slug
        L = []
        L.append("# %d. %s · 离线知识分片" % (d["ordinal"], d["name"]))
        L.append("")
        L.append("> **性质**：本资产**自建离线知识层**（由 `make_offline_kb.py` 从 ht_library.sqlite 自动生成，"
                 "时点 %s）。域—专题—单元标题三级索引，供知识库通道不可用时做导航与概览。" % stamp)
        L.append("> **纪律**：本层**不含任何单元正文**；形态为内部索引，**不得原样输出给用户**。")
        L.append("")
        L.append("> **纪律**：本层**不含任何单元正文**，**不含规模数字与分布统计**；形态为内部索引，**不得原样输出给用户**。")
        L.append("")
        L.append("## 一、专题索引")
        L.append("")
        for t in dts:
            tus = by_topic.get(t["topic_id"], [])
            tchars = sum((u["chars"] or 0) for u in tus)
            tkind = Counter(u["kind"] for u in tus)
            tplace = Counter((u["place"] or "").strip() for u in tus if (u["place"] or "").strip())
            al = aliases.get(t["topic_id"], [])
            L.append("### %s（`%s`）" % (t["name"], t["topic_id"]))
            L.append("")
            if al:
                L.append("- 别名：" + "、".join(al))
            if t["scope_note"]:
                L.append("- 范围说明：" + str(t["scope_note"]).replace("\n", " ").strip())
            if tus:
                L.append("- 单元标题：")
                for u in tus:
                    title = (u["unit_title"] or "").strip() or "（未拟题）"
                    L.append("  - %s" % title)  # 合规口径：不落内部键
            else:
                L.append("- 单元标题：（本专题暂无单元）")
            L.append("")
        (out / fname).write_text("\n".join(L), encoding="utf-8")
        files.append(fname)
        index_rows.append((d["ordinal"], d["domain_id"], d["name"], len(dts), len(dus), dchars, fname))

    # ---------- 总索引 ----------
    I = []
    I.append("# 离线知识层 · 总索引（自建）")
    I.append("")
    I.append("> **这是什么**：郴州全域知识专家的**自建离线知识层**——由 `make_offline_kb.py` "
             "**只读**读取 `ht_library.sqlite`（瀚天知识库对外知识单元层）自动生成，"
             "把全域固化为「域—专题—单元标题」三级索引。")
    I.append("> **生成时点**：%s ｜ **来源库**：`ht_library.sqlite` ｜ **口径**：仅域—专题—单元标题索引，不含规模数字与分布统计（合规口径）。"
             % stamp_full)
    I.append("> **它不是什么**：**不是**库内正文，**不是**最终答案；**不含任何单元正文片段**，"
             "条目均为索引级（专题名 / 单元标题）。")
    I.append("> **与「瀚天智库」离线知识档的关系**：**无**。本层为本资产独立自建，"
             "命名、结构、条目口径与来源均不同于既有任何资产。")
    I.append("")
    I.append("---")
    I.append("")
    I.append("## 一、使用规则（强制）")
    I.append("")
    I.append("| 情形 | 怎么做 |")
    I.append("|---|---|")
    I.append("| **知识库通道可用**（公网连接器或包内快照） | **现场查询是答案来源**；本层只作内部预习与导航，"
             "**不得原样输出** |")
    I.append("| **通道均不可用** | 可用本层做**导航与概览**（如「某领域有哪些专题可查」「某专题大致覆盖什么」，只作定性描述，不报数量）；"
             "回答开头须标注本层时点：`⚠️ 以下基于离线知识层（%s），未经实时库复核` |" % stamp)
    I.append("| **本层未覆盖** | **如实说未覆盖**，不得由相邻条目推理补全、不得凭模型记忆补细节 |")
    I.append("| **涉及具体史实细节** | 须回通道查证后再消化表述；**本层只有索引，不含细节** |")
    I.append("")
    I.append("**铁律不变**：本层与实时库一样——**没有就是没有**；本层只是「接不上时不至于盲」，"
             "不是「可以少查一点」，更不是「可以照抄」。")
    I.append("")
    I.append("---")
    I.append("")
    I.append("## 二、域—专题总表")
    I.append("")
    I.append("| # | 域 | 域编号 | 分片文件 |")
    I.append("|---|---|---|---|")
    for ord_, did, dname, ntopic, nunits, dchars, fname in index_rows:
        I.append("| %d | %s | `%s` | `%s` |" % (ord_, dname, did, fname))
    I.append("")
    I.append("## 三、分片地图（按问题找文件）")
    I.append("")
    for ord_, did, dname, ntopic, nunits, dchars, fname in index_rows:
        sample = "、".join(t["name"] for t in topics_by_domain.get(did, [])[:6])
        I.append("- `%s` —— **%s**：%s%s"
                 % (fname, dname, sample, "…" if ntopic > 6 else ""))
    I.append("")
    I.append("---")
    I.append("")
    I.append("## 四、维护")
    I.append("")
    I.append("```bash")
    I.append('python "<技能目录>/scripts/make_offline_kb.py"')
    I.append("```")
    I.append("")
    I.append("**只读生成，不改动源库。** 库有新增单元后重新运行即可刷新本层。")
    I.append("")
    (out / "00-index.md").write_text("\n".join(I), encoding="utf-8")

    meta = {
        "generated_at": stamp,
        "generated_at_full": stamp_full,
        "source_db": str(db),
        "layer": "self-built offline knowledge layer (independent from any other asset)",
        "files": ["00-index.md"] + files,
        "note": "本层仅含域—专题—单元标题索引，不含单元正文、不含规模数字与分布统计（合规口径）；形态为内部材料，不得原样输出给用户。",
    }
    (out / "_offline_kb_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    con.close()
    print("✅ 离线知识层已生成：%s" % out)
    print("   域 %d / 专题 %d / 单元 %d / 字 %d" % (len(domains), len(topics), total_units, total_chars))
    print("   文件：%s" % "、".join(["00-index.md"] + files))

    sys.exit(0)


if __name__ == "__main__":
    main()
