#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""郴州全域知识专家 · 本库只读查询接口（kb_query.py）

用途
    对 ht_library.sqlite（瀚天知识库对外知识单元层）做**只读**查询。
    本脚本是整个智能体唯一的知识访问入口，供「通道探测 → 库内深读 → 原创输出」使用。

铁律
    · 一律以 mode=ro（只读）打开，绝不写库、绝不 ATTACH 跨库、绝不导出整表；
    · 不修改、不删除、不批量转储库内数据。

通道解析顺序
    1) --db 显式指定
    2) 包内只读快照（<包根>/assets/ht_library_snapshot.sqlite，兜底，须标注时点）
    ※ 本机实时库通道已于 v1.8.0 移除——知识一律经公网连接器（实时）或包内自建兜底（快照/离线层）获取。

用法
    python kb_query.py stats
    python kb_query.py channel
    python kb_query.py domains
    python kb_query.py topics [--domain HT-CUL] [--min-units N]
    python kb_query.py search --q "湘南起义 郴州" [--topic HT-RED-00001] [--domain HT-RED]
                              [--kind narrative] [--snature folklore] [--place 宜章]
                              [--channel doc|web] [--limit 20] [--offset 0] [--full]
    python kb_query.py unit --id <单元句柄> [--full]
    python kb_query.py unit --id <单元句柄> --window "关键词" [--span 80]   # ★v1.1 推荐
    python kb_query.py scope [--list]              # 照搬豁免范围（条数；--list 列明细）
    python kb_query.py is-verbatim --id KU-...     # 单条是否属豁免
    python kb_query.py aliases [--topic HT-...]
"""

import argparse
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent            # .../skills/chenzhou-kb-ops/scripts
PKG_ROOT = BASE.parents[2]                        # .../<pkg>
# ※ 本机实时库通道已移除（v1.8.0）：不设 HT_LIVE_DB、不写死任何宿主机路径。
#   知识来源＝公网连接器（由宿主建立，脚本不做 sqlite 访问）＋ 包内自建兜底（快照/离线层）。
SNAPSHOT_DB = PKG_ROOT / "assets" / "ht_library_snapshot.sqlite"
SNAPSHOT_META = PKG_ROOT / "assets" / "_snapshot_meta.json"
OFFLINE_KB = PKG_ROOT / "assets" / "offline_kb"          # 自建离线知识层（第二兜底，非 sqlite）
OFFLINE_META = OFFLINE_KB / "_offline_kb_meta.json"
ALLOW_JSON = BASE / "verbatim_allow.json"
S2T_MAP = BASE / "s2t_map.txt"

SEP_SUFFIX = "（"


# ---------------- 简繁互查（繁→简） ----------------
def load_t2s():
    m = {}
    if not S2T_MAP.exists():
        return m
    try:
        for tok in S2T_MAP.read_text(encoding="utf-8").split():
            if len(tok) < 2:
                continue
            simp, trads = tok[0], tok[1:]
            for t in trads:
                m[t] = simp
    except Exception:
        pass
    return m


T2S = load_t2s()


def t2s(s):
    if not s or not T2S:
        return s or ""
    return "".join(T2S.get(ch, ch) for ch in s)


# ---------------- 通道解析 ----------------
def resolve_db(explicit=None):
    if explicit:
        p = Path(explicit)
        if p.exists():
            return p, "explicit"
        sys.exit("❌ --db 指定的库不存在：%s" % explicit)
    if SNAPSHOT_DB.exists():
        return SNAPSHOT_DB, "snapshot"
    sys.exit("❌ 知识库通道不可用：包内快照缺失。\n"
             "   若包内离线知识层（assets/offline_kb/）在位，可只用它做**导航与概览**"
             "（不含正文、不得据标题推内容）；否则请如实告知用户并停止作答"
             "（宿主已连接公网连接器「瀚天知识库」时除外）。")


def connect(db):
    try:
        con = sqlite3.connect("file:%s?mode=ro" % str(db).replace("\\", "/"), uri=True)
    except sqlite3.OperationalError as e:
        sys.exit("❌ 无法以只读方式打开知识库：%s（%s）" % (db, e))
    con.row_factory = sqlite3.Row
    return con


def channel_banner(kind, db):
    if kind == "snapshot":
        meta = ""
        ts = ""
        if SNAPSHOT_META.exists():
            try:
                mj = json.loads(SNAPSHOT_META.read_text(encoding="utf-8"))
                ts = mj.get("snapshot_at", "")
                meta = "（快照时点 %s；单元 %s）" % (ts, mj.get("counts", {}).get("units", "?"))
            except Exception:
                pass
        return "[通道] 包内只读快照 · %s%s\n⚠️ 请务必在回答开头标注：本次回答基于库快照（时点：%s），未经实时库复核。" % (
            db, meta, ts or "未知")
    return "[通道] 显式指定 · %s" % db


# ---------------- 照搬豁免判据 ----------------
def load_allow():
    try:
        return json.loads(ALLOW_JSON.read_text(encoding="utf-8"))
    except Exception:
        return {"predicates": {}, "deny": []}


def head_of(source_note):
    s = (source_note or "").strip()
    for sep in ("（", "("):
        i = s.find(sep)
        if i >= 0:
            s = s[:i]
    return s.strip()


def is_verbatim(row, allow):
    """row 需含 unit_id / kind / source_nature / source_note"""
    uid = row["unit_id"]
    for d in allow.get("deny", []) or []:
        if d.get("unit_id") == uid:
            return False, "deny:unit_id"
        if d.get("kind") and d["kind"] == row["kind"]:
            return False, "deny:kind=%s" % d["kind"]
        if d.get("source_nature") and d["source_nature"] == row["source_nature"]:
            return False, "deny:source_nature=%s" % d["source_nature"]
        if d.get("source_note_head") and d["source_note_head"] == head_of(row["source_note"]):
            return False, "deny:source_note_head=%s" % d["source_note_head"]

    p = allow.get("predicates", {}) or {}
    if row["kind"] in (p.get("kind") or []):
        return True, "kind=%s" % row["kind"]
    if row["source_nature"] in (p.get("source_nature") or []):
        return True, "source_nature=%s" % row["source_nature"]
    if head_of(row["source_note"]) in (p.get("source_note_head") or []):
        return True, "source_note_head=%s" % head_of(row["source_note"])
    return False, ""


def scope_where(allow):
    p = allow.get("predicates", {}) or {}
    clauses, params = [], []
    if p.get("kind"):
        clauses.append("kind IN (%s)" % ",".join("?" * len(p["kind"])))
        params += p["kind"]
    if p.get("source_nature"):
        clauses.append("source_nature IN (%s)" % ",".join("?" * len(p["source_nature"])))
        params += p["source_nature"]
    if p.get("source_note_head"):
        sub = []
        for h in p["source_note_head"]:
            sub.append("(source_note = ? OR source_note LIKE ?)")
            params += [h, h + "（%"]
        clauses.append("(" + " OR ".join(sub) + ")")
    w = " OR ".join(clauses) if clauses else "0"
    deny = allow.get("deny", []) or []
    for d in deny:
        if d.get("unit_id"):
            w += " AND unit_id <> ?"
            params.append(d["unit_id"])
        if d.get("kind"):
            w += " AND kind <> ?"
            params.append(d["kind"])
        if d.get("source_nature"):
            w += " AND source_nature <> ?"
            params.append(d["source_nature"])
        if d.get("source_note_head"):
            w += " AND NOT (source_note = ? OR source_note LIKE ?)"
            params += [d["source_note_head"], d["source_note_head"] + "（%"]
    return w, params


# ---------------- 命令实现 ----------------
def cmd_channel(a):
    print("=== 三通道降级序列探测（公网连接器 → 包内快照 → 离线知识层）===")
    # 第 0 步：公网连接器（由宿主按 .mcp.json 声明建立，本地脚本无法自检连通性）
    print("[0 最优先] 公网连接器「瀚天知识库」＝https://www.ht-think.com/mcp")
    print("            → 可用时优先；不可用（未连接／配额不足／网络不通）则静默回落至下方通道")
    print("            → 判活看 library_stats 返回 available == true（规模字段自 2026-11-02 起不出库），禁用写死值")
    # 第 1 步：包内只读快照
    if SNAPSHOT_DB.exists():
        print("[1 兜底] 包内只读快照在位：%s" % SNAPSHOT_DB)
        if SNAPSHOT_META.exists():
            print(SNAPSHOT_META.read_text(encoding="utf-8"))
    else:
        print("[1 兜底] 包内只读快照缺失：%s" % SNAPSHOT_DB)
    # 第 2 步：离线知识层（非 sqlite，供导航/概览；空目录视为缺失）
    has_offline = OFFLINE_KB.exists() and any(OFFLINE_KB.glob("*.md"))
    if has_offline:
        info = ""
        if OFFLINE_META.exists():
            try:
                mj = json.loads(OFFLINE_META.read_text(encoding="utf-8"))
                c = mj.get("counts", {})
                info = "（时点 %s；%s 域 / %s 专题 / %s 单元）" % (
                    mj.get("generated_at", "?"), c.get("domains", "?"), c.get("topics", "?"), c.get("units", "?"))
            except Exception:
                pass
        print("[2 兜底] 自建离线知识层在位：%s%s" % (OFFLINE_KB, info))
        print("          ⚠️ 仅可导航与概览（不含正文）；涉具体史实须连库复核")
    else:
        print("[2 兜底] 自建离线知识层缺失（空目录，待经公网连接器重建）：%s" % OFFLINE_KB)
    # 结论
    print("---")
    if SNAPSHOT_DB.exists():
        print("✅ 当前可用通道：包内只读快照（请在回答开头标注快照时点）；如连接器已连接则连接器更优先")
    elif has_offline:
        print("⚠️ 当前仅剩离线知识层：只可做导航与概览，须在回答开头标注离线层时点")
    else:
        print("❌ 以上通道皆不可用：请如实告知用户并停止作答（连接器仍可用时除外）")


def cmd_stats(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    c = con.cursor()
    one = lambda s: c.execute(s).fetchone()[0]
    print(channel_banner(kind, db))
    print("— 郴州全域知识专家 · 库内统计 —")
    print("单元总数 units        :", one("select count(*) from units"))
    print("全文索引 units_fts    :", one("select count(*) from units_fts"))
    print("汉字合计 SUM(chars)   :", one("select sum(chars) from units"))
    print("专题 topics           :", one("select count(*) from topics"))
    print("域 domains            :", one("select count(*) from domains"))
    print("专题链接 topic_links  :", one("select count(*) from topic_links"))
    print("专题别名 topic_aliases:", one("select count(*) from topic_aliases"))
    print()
    print("▸ 按域分布")
    for r in c.execute("""select d.name, count(u.unit_id) n, sum(u.chars) ch
                          from units u join topics t on t.topic_id=u.topic_id
                          join domains d on d.domain_id=t.domain_id
                          group by d.domain_id order by d.ordinal"""):
        print("   %-16s %5d 单元 / %8s 字" % (r["name"], r["n"], r["ch"]))
    print()
    print("▸ 按体裁 kind")
    for r in c.execute("select kind, count(*) n from units group by kind order by n desc"):
        print("   %-12s %5d" % (r["kind"], r["n"]))
    print()
    print("▸ 按来源性质 source_nature")
    for r in c.execute("select source_nature, count(*) n from units group by 1 order by n desc"):
        print("   %-16s %5d" % (r["source_nature"], r["n"]))
    print()
    print("▸ 按来源通道 source_channel")
    for r in c.execute("select source_channel, count(*) n from units group by 1 order by n desc"):
        print("   %-6s %5d" % (r["source_channel"], r["n"]))
    con.close()


def cmd_domains(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    print(channel_banner(kind, db))
    for r in con.execute("""select d.domain_id, d.name, d.ordinal,
                                   count(t.topic_id) ntop, coalesce(sum(t.unit_count),0) nu
                            from domains d left join topics t on t.domain_id=d.domain_id
                            group by d.domain_id order by d.ordinal"""):
        print("%-12s %-18s ordinal=%-3s 专题=%-4s 单元≈%s"
              % (r["domain_id"], r["name"], r["ordinal"], r["ntop"], r["nu"]))
    con.close()


def cmd_topics(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    print(channel_banner(kind, db))
    sql = "select topic_id, domain_id, name, unit_count, status, source_channel, scope_note from topics"
    w, ps = [], []
    if a.domain:
        w.append("domain_id = ?")
        ps.append(a.domain)
    if a.min_units:
        w.append("unit_count >= ?")
        ps.append(a.min_units)
    if w:
        sql += " where " + " and ".join(w)
    sql += " order by topic_id"
    for r in con.execute(sql, ps):
        note = ("  ‖ " + r["scope_note"][:40]) if r["scope_note"] else ""
        print("%-18s %-10s %-26s 单元=%-5s %s/%s%s"
              % (r["topic_id"], r["domain_id"], r["name"], r["unit_count"],
                 r["status"], r["source_channel"], note))
    con.close()


def load_alias_map():
    p = BASE / "aliases.json"
    m = {}
    if not p.exists():
        return m
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}
    for k, vs in data.items():
        if str(k).startswith("_"):
            continue
        group = {str(k)} | {str(v) for v in (vs or [])}
        for w in group:
            m.setdefault(w, set()).update(group)
    return m


ALIAS_MAP = load_alias_map()


def expand(term, enabled=True):
    """把一个检索词扩展为同义组（含自身）。"""
    if not enabled:
        return {term}
    out = {term}
    for w, group in ALIAS_MAP.items():
        if w == term or (len(w) >= 2 and (w in term or term in w)):
            out.update(group)
    return {x for x in out if x}


def cmd_search(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    print(channel_banner(kind, db))
    terms = [t2s(t) for t in (a.q or "").split() if t.strip()]
    if not terms:
        sys.exit("❌ 请用 --q 给出检索词（多词空格分隔＝AND）")
    where, params = [], []
    for t in terms:
        alts = sorted(expand(t, not a.no_expand))
        sub = []
        for w in alts:
            sub.append("(coalesce(unit_title,'') LIKE ? OR content LIKE ?)")
            params += ["%" + w + "%", "%" + w + "%"]
        where.append("(" + " OR ".join(sub) + ")")
    if a.topic:
        where.append("topic_id = ?"); params.append(a.topic)
    if a.domain:
        where.append("topic_id IN (select topic_id from topics where domain_id = ?)"); params.append(a.domain)
    if a.kind:
        where.append("kind = ?"); params.append(a.kind)
    if a.snature:
        where.append("source_nature = ?"); params.append(a.snature)
    if a.place:
        where.append("place LIKE ?"); params.append("%" + a.place + "%")
    if a.channel:
        where.append("source_channel = ?"); params.append(a.channel)
    if a.corro:
        where.append("corroboration = ?"); params.append(a.corro)
    sql = ("select unit_id, topic_id, kind, source_nature, unit_title, place, era_from, era_to, "
           "chars, source_channel, corroboration, content from units where " + " and ".join(where) +
           " order by chars desc limit ? offset ?")
    params += [a.limit, a.offset]
    rows = con.execute(sql, params).fetchall()
    total = con.execute("select count(*) from units where " + " and ".join(where),
                        params[:-2]).fetchone()[0]
    print("命中 %d 条（显示 %d 条，offset=%d）｜检索词：%s" % (total, len(rows), a.offset, " ".join(terms)))
    for r in rows:
        print("-" * 72)
        print("【%s】%s" % (r["unit_id"], r["unit_title"] or "(无题)"))
        print("   专题=%s 体裁=%s 性质=%s 地域=%s 年代=%s~%s 通道=%s 互证=%s 字数=%s"
              % (r["topic_id"], r["kind"], r["source_nature"], r["place"] or "",
                 r["era_from"] or "", r["era_to"] or "", r["source_channel"],
                 r["corroboration"], r["chars"]))
        if a.full:
            print(r["content"])
        else:
            print("   " + (r["content"] or "")[:160].replace("\n", " ") + ("…" if r["chars"] > 160 else ""))
    con.close()


def cmd_unit(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    print(channel_banner(kind, db))
    r = con.execute("select * from units where unit_id = ?", (a.id,)).fetchone()
    if not r:
        sys.exit("❌ 未找到单元 %s" % a.id)
    d = dict(r)
    allow = load_allow()
    ex, why = is_verbatim(r, allow)
    for k, v in d.items():
        if k == "content":
            continue
        print("%-16s %s" % (k, v))
    print("%-16s %s" % ("照搬豁免", ("是  ← %s（可原文输出）" % why) if ex else "否（须原创表述）"))
    print("--- content ---")
    content = d["content"] or ""
    if a.window:
        # ★v1.1：只取关键词周围的窗口（默认 80 字），避免整篇外显
        span = max(1, min(int(a.span or 80), 200))
        hay = t2s(content)                       # 简繁归一后再定位
        needle = t2s(a.window)
        i = hay.find(needle)
        if i < 0:
            print("（未在正文中命中关键词「%s」；尝试按其中单字定位）" % a.window)
            for ch in needle:
                i = hay.find(ch)
                if i >= 0:
                    break
        if i < 0:
            print("（关键词未命中，退回开头窗口）")
            i = 0
        lo = max(0, i - span // 2)
        hi = min(len(content), i + len(a.window) + span // 2)
        print("…（窗口 %d–%d / 全篇 %d 字，span=%d）" % (lo, hi, len(content), span))
        print(content[lo:hi])
        print("…")
        print("※ 窗口取文仅用于判断相关性；表述仍须原创（红线一）；不得落盘、不得外传。")
    else:
        print(content if a.full else (content[:200] + ("…" if d["chars"] > 200 else "")))
    con.close()


def cmd_scope(a):
    db, kind = resolve_db(a.db)
    allow = load_allow()
    con = connect(db)
    print(channel_banner(kind, db))
    w, ps = scope_where(allow)
    n = con.execute("select count(*) from units where " + w, ps).fetchone()[0]
    print("— 照搬豁免判定范围（v%s，判据正本 %s）—" % (allow.get("version", "?"), ALLOW_JSON.name))
    print("命中单元合计：%d / %d（%.1f%%）" % (n, con.execute("select count(*) from units").fetchone()[0],
                                             100.0 * n / max(1, con.execute("select count(*) from units").fetchone()[0])))
    for key, vals in (allow.get("predicates") or {}).items():
        print("   判据 %-18s ∈ %s" % (key, vals))
    if allow.get("deny"):
        print("   否决 deny：%s" % json.dumps(allow["deny"], ensure_ascii=False))
    else:
        print("   否决 deny：（空）")
    if a.list:
        print("\n明细：")
        for r in con.execute("select unit_id, topic_id, kind, source_nature, source_note, unit_title "
                             "from units where " + w + " order by unit_id", ps):
            print("   %-26s %-12s %-10s %-16s %s｜%s"
                  % (r["unit_id"], r["topic_id"], r["kind"], r["source_nature"],
                     head_of(r["source_note"]), r["unit_title"]))
    con.close()


def cmd_is_verbatim(a):
    db, kind = resolve_db(a.db)
    allow = load_allow()
    con = connect(db)
    r = con.execute("select * from units where unit_id = ?", (a.id,)).fetchone()
    if not r:
        sys.exit("❌ 未找到单元 %s" % a.id)
    ex, why = is_verbatim(r, allow)
    print(json.dumps({"unit_id": a.id, "exempt": ex, "reason": why,
                      "kind": r["kind"], "source_nature": r["source_nature"],
                      "source_note_head": head_of(r["source_note"])}, ensure_ascii=False))
    con.close()


def cmd_aliases(a):
    db, kind = resolve_db(a.db)
    con = connect(db)
    print(channel_banner(kind, db))
    sql = "select topic_id, alias, weight, source from topic_aliases"
    ps = []
    if a.topic:
        sql += " where topic_id = ?"
        ps.append(a.topic)
    sql += " order by topic_id, weight desc"
    for r in con.execute(sql, ps):
        print("%-18s %-22s w=%-4s %s" % (r["topic_id"], r["alias"], r["weight"], r["source"]))
    con.close()


def main():
    ap = argparse.ArgumentParser(description="郴州全域知识专家 · 本库只读查询接口")
    ap.add_argument("--db", help="显式指定 sqlite 路径（默认：包内只读快照）")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("channel", help="通道探测")
    sub.add_parser("stats", help="库内总体统计与分布")
    sub.add_parser("domains", help="列出 14 个域")
    p = sub.add_parser("topics", help="列出专题"); p.add_argument("--domain"); p.add_argument("--min-units", type=int, dest="min_units")
    p = sub.add_parser("search", help="全文检索（LIKE 子串，多词 AND，支持简繁互查）")
    p.add_argument("--q", required=True); p.add_argument("--topic"); p.add_argument("--domain")
    p.add_argument("--kind"); p.add_argument("--snature", dest="snature"); p.add_argument("--place")
    p.add_argument("--channel"); p.add_argument("--corro", dest="corro")
    p.add_argument("--limit", type=int, default=20); p.add_argument("--offset", type=int, default=0)
    p.add_argument("--full", action="store_true")
    p.add_argument("--no-expand", action="store_true", dest="no_expand", help="关闭别名同义扩展")
    p = sub.add_parser("unit", help="取单条单元"); p.add_argument("--id", required=True); p.add_argument("--full", action="store_true")
    p.add_argument("--window", help="★v1.1：只取关键词周围的窗口（避免整篇外显）")
    p.add_argument("--span", type=int, default=80, help="★v1.1：窗口字数（默认 80，上限 200）")
    p = sub.add_parser("scope", help="照搬豁免范围"); p.add_argument("--list", action="store_true")
    p = sub.add_parser("is-verbatim", help="单条是否属豁免"); p.add_argument("--id", required=True)
    p = sub.add_parser("aliases", help="专题别名表"); p.add_argument("--topic")

    a = ap.parse_args()
    if not a.cmd:
        ap.print_help(); sys.exit(0)
    {"channel": cmd_channel, "stats": cmd_stats, "domains": cmd_domains, "topics": cmd_topics,
     "search": cmd_search, "unit": cmd_unit, "scope": cmd_scope, "is-verbatim": cmd_is_verbatim,
     "aliases": cmd_aliases}[a.cmd](a)


if __name__ == "__main__":
    main()
