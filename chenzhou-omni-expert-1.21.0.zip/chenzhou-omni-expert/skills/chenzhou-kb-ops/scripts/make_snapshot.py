#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""郴州全域知识专家 · 生成包内只读快照（make_snapshot.py）

用途
    把 ht_library.sqlite 复制为包内只读快照，供连接器不可用时兜底。
    **只读复制，绝不改动源库**（用 sqlite3 的在线备份接口，保证一致性）。
    ※ v1.8.0：本机实时库通道已移除——本脚本保留为维护工具，须显式 --src 传源库路径；
      快照／离线层的常规重建将改由公网连接器执行（待设计者指令）。

用法
    python make_snapshot.py [--src <源库路径>] [--dst <目标路径>] [--meta <元数据路径>]

默认
    源：由 --src 显式指定（不再支持环境变量默认源）
    目标：<包根>/assets/ht_library_snapshot.sqlite
    元数据：<包根>/assets/_snapshot_meta.json
"""

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
PKG_ROOT = BASE.parents[2]
DEFAULT_DST = PKG_ROOT / "assets" / "ht_library_snapshot.sqlite"
DEFAULT_META = PKG_ROOT / "assets" / "_snapshot_meta.json"

TABLES = ["units", "units_fts", "topics", "topics_fts", "topic_links", "topic_aliases", "domains"]


def main():
    ap = argparse.ArgumentParser(description="生成包内只读快照")
    ap.add_argument("--src", required=True,
                    help="源库路径（显式指定；不再支持环境变量默认源）")
    ap.add_argument("--dst", default=str(DEFAULT_DST))
    ap.add_argument("--meta", default=str(DEFAULT_META))
    a = ap.parse_args()

    src, dst = Path(a.src), Path(a.dst)
    if not src.exists():
        sys.exit("❌ 源库不存在：%s" % src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()

    # 在线备份（一致性快照；不改动源库）
    s = sqlite3.connect("file:%s?mode=ro" % str(src).replace("\\", "/"), uri=True)
    d = sqlite3.connect(str(dst))
    with d:
        s.backup(d)
    d.close()
    s.close()

    # 校验与元数据
    c = sqlite3.connect("file:%s?mode=ro" % str(dst).replace("\\", "/"), uri=True)
    counts = {}
    for t in TABLES:
        try:
            counts[t] = c.execute("select count(*) from %s" % t).fetchone()[0]
        except Exception as e:
            counts[t] = "ERR:%s" % e
    try:
        counts["SUM_chars"] = c.execute("select sum(chars) from units").fetchone()[0]
    except Exception:
        counts["SUM_chars"] = None
    c.close()

    ok = counts.get("units") == counts.get("units_fts")
    meta = {
        "snapshot_at": datetime.now().strftime("%Y-%m-%d"),
        "snapshot_at_full": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": src.name,
        "file": dst.name,
        "size_bytes": dst.stat().st_size,
        "counts": counts,
        "symmetry_units_fts_ok": ok,
        "note": "本快照为时点冻结副本，只读；回答中须标注其快照时点。",
    }
    Path(a.meta).write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print("✅ 快照已生成：%s（%.1f MB）" % (dst, dst.stat().st_size / 1048576))
    print("   元数据：%s" % a.meta)
    print("   计数：" + json.dumps(counts, ensure_ascii=False))
    print("   units ≡ units_fts：" + ("是" if ok else "❌ 否（请检查）"))

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
