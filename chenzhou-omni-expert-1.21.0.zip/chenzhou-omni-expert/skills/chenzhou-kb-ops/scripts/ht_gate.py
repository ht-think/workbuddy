#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""郴州全域知识专家 · 回答合规闸门（ht_gate.py）

用途
    回答草稿写完后、给用户之前，校验它与**本库单元正文**的重合度是否越线。
    判据与「瀚天智库」gate_check.py v2 **完全同口径**，唯一差异＝**照搬豁免通道**：
    属于豁免类别的库内内容不参与重合判定。

判据（先掩码，再比对"剩余连续文字"）
    掩码：题名（回答与证据中所有《…》内容）、专题别名表专名、数字串
    豁免区：回答末尾「素材来源 / 资料来源 / 依据说明」之后的区段不参与比对
    照搬豁免：--waiver-unit 显式指定 / --auto-waiver 按 verbatim_allow.json 判据自动收集
              / --waiver-file 指定豁免原文文件；豁免内容先从证据中剔除，再比对。
    R1  最长连续重合 ≥ 18 字                      → 成句照搬
    R2  累计重合 ≥ 100 字 且 占回答正文 ≥ 15%      → 大面积搬运
    R3  引号内 ≥ 15 字 与原文重合                  → 引原文
    10–17 字零散重合不拦，仅作 hint 列出

用法
    python ht_gate.py --answer draft.txt --evidence evidence.txt
    python ht_gate.py --answer draft.txt --evidence-ids KU-XXX-00001-0000001 --auto-waiver
    python ht_gate.py --answer draft.txt --evidence evidence.txt --db "<库路径>" --auto-waiver
    python ht_gate.py --answer draft.txt --evidence evidence.txt --waiver-unit <单元句柄>
    python ht_gate.py --answer draft.txt --evidence evidence.txt --json

★ v1.1.0 新增
    --evidence-ids   传单元号（逗号/空格分隔），由**脚本自己从库里取正文**，
                     不需要、也不建议把库内正文落盘成文件（中间产物纪律）。
    --self-destruct  闸门跑完自动删除 --evidence 指定的文件，避免正文残留。

退出码
    0 = 通过 ｜ 1 = 违规（须重写） ｜ 2 = 未生效（缺回答或证据，等同没校验）
"""

import argparse
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
PKG_ROOT = BASE.parents[2]
# ※ 本机实时库通道已移除（v1.8.0）：不再读 HT_LIVE_DB；豁免收集只读包内快照。
SNAPSHOT_DB = PKG_ROOT / "assets" / "ht_library_snapshot.sqlite"
ALLOW_JSON = BASE / "verbatim_allow.json"

SEP = "\ue000"
DEFAULT_NGRAM = 10
DEFAULT_R1 = 18
DEFAULT_R2_TOTAL = 100
DEFAULT_R2_RATIO = 0.15
DEFAULT_R3 = 15
TAIL_MARKERS = ("素材来源", "资料来源", "依据说明")
MAX_EVIDENCE_CHARS = 4_000_000


def load_t2s():
    p = BASE / "s2t_map.txt"
    m = {}
    if not p.exists():
        return m
    try:
        for tok in p.read_text(encoding="utf-8").split():
            if len(tok) < 2:
                continue
            simp, trads = tok[0], tok[1:]
            for t in trads:
                m[t] = simp
    except Exception:
        return {}
    return m


T2S = load_t2s()
_PUNCT_RE = re.compile(r"[\s\u3000\u3001-\u303f\uff01-\uff5e!-/:-@\[-`{-~]+")


def normalize(s):
    if not s:
        return ""
    if T2S:
        s = "".join(T2S.get(ch, ch) for ch in s)
    return _PUNCT_RE.sub("", s)


TITLE_RE = re.compile(r"《([^》]{2,60})》")


def titles_in(s):
    return {m.strip() for m in TITLE_RE.findall(s or "") if len(m.strip()) >= 2}


def load_alias_terms():
    terms = set()
    p = BASE / "aliases.json"
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            for k, vs in data.items():
                if str(k).startswith("_"):
                    continue
                if len(str(k)) >= 2:
                    terms.add(str(k))
                for v in (vs or []):
                    if len(str(v)) >= 2:
                        terms.add(str(v))
        except Exception:
            pass
    return terms


def mask(text, protected):
    if not text:
        return ""
    t = text
    for p in sorted(protected, key=len, reverse=True):
        if p and p in t:
            t = t.replace(p, SEP)
    t = re.sub(r"[0-9０-９]+", SEP, t)
    return t


def strip_tail(answer):
    idx = len(answer)
    for m in TAIL_MARKERS:
        i = answer.find(m)
        if i >= 0:
            idx = min(idx, i)
    return answer[:idx]


# ---------------- 照搬豁免收集 ----------------
def head_of(source_note):
    s = (source_note or "").strip()
    for sep in ("（", "("):
        i = s.find(sep)
        if i >= 0:
            s = s[:i]
    return s.strip()


def load_allow(path=None):
    p = Path(path) if path else ALLOW_JSON
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"predicates": {}, "deny": []}


def find_db(explicit=None):
    if explicit and Path(explicit).exists():
        return Path(explicit)
    if SNAPSHOT_DB.exists():
        return SNAPSHOT_DB
    return None


def collect_waived(auto_waiver, waiver_units, waiver_file, db_path, allow_path):
    """返回 (waived_texts:list[str], notes:list[str])"""
    texts, notes = [], []
    need_db = auto_waiver or waiver_units

    if waiver_file:
        try:
            texts.append(Path(waiver_file).read_text(encoding="utf-8", errors="replace"))
            notes.append("--waiver-file %s" % waiver_file)
        except Exception as e:
            sys.exit("❌ 无法读取豁免文件 %s：%s" % (waiver_file, e))

    if not need_db:
        return texts, notes

    db = find_db(db_path)
    if db is None:
        sys.exit("❌ 需要读库收集豁免内容，但包内快照不可用（可在连接器可用时改用 --waiver-file 显式传入豁免原文）。")
    con = sqlite3.connect("file:%s?mode=ro" % str(db).replace("\\", "/"), uri=True)
    con.row_factory = sqlite3.Row

    if waiver_units:
        for uid in waiver_units:
            r = con.execute("select content from units where unit_id = ?", (uid,)).fetchone()
            if r:
                texts.append(r["content"])
            else:
                notes.append("--waiver-unit %s（未找到，已忽略）" % uid)
        notes.append("--waiver-unit ×%d" % len(waiver_units))

    if auto_waiver:
        allow = load_allow(allow_path)
        p = allow.get("predicates", {}) or {}
        clauses, params = [], []
        if p.get("kind"):
            clauses.append("kind IN (%s)" % ",".join("?" * len(p["kind"]))); params += p["kind"]
        if p.get("source_nature"):
            clauses.append("source_nature IN (%s)" % ",".join("?" * len(p["source_nature"]))); params += p["source_nature"]
        if p.get("source_note_head"):
            sub = []
            for h in p["source_note_head"]:
                sub.append("(source_note = ? OR source_note LIKE ?)"); params += [h, h + "（%"]
            clauses.append("(" + " OR ".join(sub) + ")")
        w = " OR ".join(clauses) if clauses else "0"
        for d in (allow.get("deny") or []):
            if d.get("unit_id"):
                w += " AND unit_id <> ?"; params.append(d["unit_id"])
            if d.get("kind"):
                w += " AND kind <> ?"; params.append(d["kind"])
            if d.get("source_nature"):
                w += " AND source_nature <> ?"; params.append(d["source_nature"])
            if d.get("source_note_head"):
                w += " AND NOT (source_note = ? OR source_note LIKE ?)"; params += [d["source_note_head"], d["source_note_head"] + "（%"]
        rows = con.execute("select content from units where " + w, params).fetchall()
        texts += [r["content"] for r in rows]
        notes.append("--auto-waiver：按判据收集 %d 条豁免单元" % len(rows))
    con.close()
    return texts, notes


# ---------------- 核心分析 ----------------
def analyze(answer, evidence_text, n, waived_texts, protected):
    body = strip_tail(answer or "")
    na = normalize(mask(body, protected))
    src = normalize(mask(evidence_text or "", protected))

    # 从证据中剔除豁免内容（先把豁免文本走同一套掩码+归一化管线，再精确子串删除）
    waived_hit = 0
    waived_norm = [normalize(mask(wt, protected)) for wt in waived_texts]
    for nw in waived_norm:
        if not nw or len(nw) < 8:
            continue
        if nw in src:
            src = src.replace(nw, SEP)
            waived_hit += 1
    # 退一步：若整段未命中（证据仅含豁免单元的一部分），按步长切片剔除
    for nw in waived_norm:
        if len(nw) < 80:
            continue
        step = 40
        for i in range(0, len(nw) - step, step):
            chunk = nw[i:i + step]
            if chunk and chunk in src:
                src = src.replace(chunk, SEP)

    if len(src) > MAX_EVIDENCE_CHARS:
        src = src[:MAX_EVIDENCE_CHARS]

    src_grams = set()
    if len(src) >= n:
        for i in range(len(src) - n + 1):
            src_grams.add(src[i:i + n])

    cov = bytearray(len(na))
    if src_grams:
        for i in range(max(0, len(na) - n + 1)):
            if na[i:i + n] in src_grams:
                cov[i:i + n] = b"\x01" * n

    longest, cur = 0, 0
    for v in cov:
        cur = cur + 1 if v else 0
        if cur > longest:
            longest = cur

    runs, i = [], 0
    while i < len(cov):
        if cov[i]:
            j = i
            while j < len(cov) and cov[j]:
                j += 1
            if j - i >= n:
                runs.append((j - i, na[i:j]))
            i = j
        else:
            i += 1
    runs.sort(key=lambda x: -x[0])

    total = sum(cov)
    ratio = (total / len(na)) if na else 0.0
    return {"body_len": len(na), "longest": longest, "total": total, "ratio": ratio,
            "runs": runs, "waived_hit": waived_hit}


def check_quotes(answer, evidence_text, n, r3, waived_texts, protected):
    src = normalize(mask(evidence_text or "", protected))
    for wt in waived_texts:
        nw = normalize(mask(wt, protected))
        if nw and len(nw) >= 8 and nw in src:
            src = src.replace(nw, SEP)
    hits = []
    for m in re.finditer(r"[“\"「『]([^”\"」』]{%d,})[”\"」』]" % r3, answer or ""):
        q = normalize(mask(m.group(1), protected))
        if len(q) >= r3 and q and q in src:
            hits.append(q[:40])
    return hits


def main():
    ap = argparse.ArgumentParser(description="郴州全域知识专家 · 回答合规闸门")
    ap.add_argument("--answer", required=True, help="回答草稿文本文件")
    ap.add_argument("--evidence", help="库内证据原文文本文件（与 --evidence-ids 二选一）")
    ap.add_argument("--evidence-ids", dest="evidence_ids", default="",
                    help="★v1.1：单元号（逗号/空格分隔），脚本自己从库里取正文，无需落盘正文")
    ap.add_argument("--self-destruct", action="store_true", dest="self_destruct",
                    help="★v1.1：闸门跑完自动删除 --evidence 文件（避免正文残留）")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--ngram", type=int, default=DEFAULT_NGRAM)
    ap.add_argument("--r1", type=int, default=DEFAULT_R1)
    ap.add_argument("--r2", type=int, default=DEFAULT_R2_TOTAL)
    ap.add_argument("--r2-ratio", type=float, default=DEFAULT_R2_RATIO, dest="r2_ratio")
    ap.add_argument("--r3", type=int, default=DEFAULT_R3)
    ap.add_argument("--db", help="库路径（收集豁免 / --evidence-ids 取正文时使用）")
    ap.add_argument("--allow", help="verbatim_allow.json 路径")
    ap.add_argument("--auto-waiver", action="store_true", dest="auto_waiver",
                    help="按 verbatim_allow.json 判据自动收集全部豁免单元并从证据中剔除")
    ap.add_argument("--waiver-unit", nargs="*", default=[], dest="waiver_unit",
                    help="显式指定豁免单元编号（可多个）")
    ap.add_argument("--waiver-file", dest="waiver_file", help="豁免原文文件（整篇视为豁免）")
    a = ap.parse_args()

    try:
        answer = Path(a.answer).read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        print("❌ 无法读取回答草稿 %s：%s" % (a.answer, e)); sys.exit(2)

    # ── 证据来源：--evidence-ids（推荐，脚本自取正文）或 --evidence（文件） ──
    src_note = ""
    if a.evidence_ids.strip():
        ids = [x for x in re.split(r"[,\s]+", a.evidence_ids.strip()) if x]
        db = find_db(a.db)
        if db is None:
            print("❌ 需要按 --evidence-ids 取正文，但库不可用（包内快照缺失）。")
            print("    请改用 --db 显式指定库路径，或在连接器可用时让服务端 gate_check 代劳。")
            sys.exit(2)
        con = sqlite3.connect("file:%s?mode=ro" % str(db).replace("\\", "/"), uri=True)
        con.row_factory = sqlite3.Row
        parts, missing = [], []
        for uid in ids:
            r = con.execute("select content from units where unit_id = ?", (uid,)).fetchone()
            if r:
                parts.append(r["content"] or "")
            else:
                missing.append(uid)
        con.close()
        evidence = "\n".join(parts)
        src_note = "--evidence-ids ×%d（自库取正文%s）" % (
            len(ids) - len(missing), ("；未找到 %d 条" % len(missing)) if missing else "")
        if not evidence.strip():
            print("❌ --evidence-ids 未取到任何正文（%s），闸门未生效。" % ("未找到 " + ",".join(missing) if missing else "空"))
            sys.exit(2)
    else:
        if not a.evidence:
            print("❌ 必须提供 --evidence 或 --evidence-ids 之一，否则闸门未生效（等同没校验）。")
            sys.exit(2)
        try:
            evidence = Path(a.evidence).read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print("❌ 无法读取证据文件 %s：%s" % (a.evidence, e)); sys.exit(2)

    if not answer.strip():
        print("❌ 回答草稿为空，闸门未生效（等同没校验）"); sys.exit(2)
    if not evidence.strip():
        print("⚠️  证据为空，闸门未生效（没有可比对的原文）。")
        print("    请用 --evidence-ids 指定本次取材的单元号后重跑——否则这次回答等于未经校验，不得视为通过。")
        sys.exit(2)

    waived, wnotes = collect_waived(a.auto_waiver, a.waiver_unit, a.waiver_file, a.db, a.allow)
    protected = set(load_alias_terms()) | titles_in(answer) | titles_in(evidence)

    m = analyze(answer, evidence, a.ngram, waived, protected)
    quotes = check_quotes(answer, evidence, a.ngram, a.r3, waived, protected)

    violations = []
    if m["longest"] >= a.r1:
        for ln, frag in m["runs"]:
            if ln >= a.r1:
                violations.append({"rule": "R1-成句照搬", "length": ln, "fragment": frag[:60]})
    if m["total"] >= a.r2 and m["ratio"] >= a.r2_ratio:
        violations.append({"rule": "R2-大面积搬运", "length": m["total"],
                           "fragment": "累计重合 %d 字，占回答正文 %.1f%%" % (m["total"], m["ratio"] * 100)})
    for q in quotes:
        violations.append({"rule": "R3-引号引原文", "length": len(q), "fragment": q})

    hints = [(ln, frag) for ln, frag in m["runs"] if a.ngram <= ln < a.r1]

    result = {
        "ok": not violations, "checked": True,
        "channel_gate": "ht_gate",
        "thresholds": {"ngram": a.ngram, "r1": a.r1, "r2_total": a.r2, "r2_ratio": a.r2_ratio, "r3": a.r3},
        "metrics": {"body_len": m["body_len"], "longest": m["longest"], "total": m["total"],
                    "ratio": round(m["ratio"], 4)},
        "waiver": {"items": len(waived), "notes": wnotes},
        "violations": violations,
        "hints": [{"length": ln, "fragment": frag[:40]} for ln, frag in hints[:5]],
    }

    if a.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("— 郴州全域知识专家 · 回答合规闸门 —")
        print("阈值：R1≥%d字 / R2≥%d字且≥%.0f%% / R3引号内≥%d字（掩码题名·专名·数字后判）"
              % (a.r1, a.r2, a.r2_ratio * 100, a.r3))
        if src_note:
            print("证据来源：%s" % src_note)
        if waived:
            print("照搬豁免：已从证据中剔除 %d 份豁免内容（%s）" % (len(waived), "；".join(wnotes) or "-"))
        else:
            print("照搬豁免：未启用（本次按全库保守模式判定）")
        print("度量：正文 %d 字｜最长连续重合 %d 字｜累计重合 %d 字（%.1f%%）"
              % (m["body_len"], m["longest"], m["total"], m["ratio"] * 100))
        if violations:
            print("\n❌ 违规 — 必须重写后再跑一次：")
            for v in violations:
                print("   · [%s] %d 字 → 「%s」" % (v["rule"], v["length"], v["fragment"]))
            print("\n重写要点：只保留事实与结论，换掉原来的句式与措辞；人名、地名、年代、数据可以照旧，"
                  "但不得连续成句沿用原文措辞，也不得加引号引原文。")
            print("若确属照搬豁免类别（韵文/民歌戏曲/古籍旧志·碑刻/公文档案），"
                  "请加 --auto-waiver 或 --waiver-unit 后重跑。")
        else:
            print("\n✅ 通过 — 未见越线重合，可以输出。")
        if hints:
            print("\n（提示，不拦：以下 %d 处为 %d–%d 字零散重合，建议顺手改掉）"
                  % (len(hints), a.ngram, a.r1 - 1))
            for ln, frag in hints[:5]:
                print("   · %d 字 → 「%s」" % (ln, frag[:40]))

    # ── ★v1.1：--self-destruct —— 清理证据文件，避免库内正文残留 ──
    if a.self_destruct:
        targets = []
        if a.evidence:
            targets.append(a.evidence)
        if a.waiver_file:
            targets.append(a.waiver_file)
        for t in targets:
            try:
                p = Path(t)
                if p.exists():
                    p.unlink()
                    if not a.json:
                        print("\n🧹 已删除证据文件：%s（--self-destruct）" % t)
            except Exception as e:
                print("\n⚠️ 删除 %s 失败：%s" % (t, e))

    sys.exit(0 if not violations else 1)


if __name__ == "__main__":
    main()
