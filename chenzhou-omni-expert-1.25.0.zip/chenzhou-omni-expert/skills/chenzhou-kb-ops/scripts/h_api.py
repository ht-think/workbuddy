#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""郴州知识检索 · 业务查询（零第三方依赖，纯标准库）。

命令（与瀚天知识库 MCP 工具一一对应，走 REST /api/v1/*）：
  python h_api.py search <关键词...> [--topic ID] [--domain X] [--limit N]
  python h_api.py get <序号|标识> [--full]        # 序号来自上一次 search；默认 digest 摘要
  python h_api.py unit <序号|标识>                # 条目事实卡（unit_brief）
  python h_api.py topics [--domain X]             # 主题分类清单
  python h_api.py topic <名称|编号>               # 主题概览（topic_brief）
  python h_api.py gate --draft <文件路径> [--query 词]   # 合规自检
  python h_api.py stats                           # 库可用状态

输出纪律：命令输出一律剥离 unit_id/topic_id/domain_id 等库内标识；检索结果为带序号的
摘要清单，取材用 `get <序号>`；序号只是本轮临时指代，不写入交付内容。

退出码：0 成功｜2 未登录/令牌失效｜4 限流｜5 积分不足（已输出充值引导）｜6 参数/服务异常
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from h_auth import (BASE_URL, TOKEN_PATH, load_token, save_token,  # noqa: E402
                    try_refresh, _req_json)

STATE_PATH = os.path.join(os.path.dirname(TOKEN_PATH) or ".", "last_search.json")

# 输出层脱敏：这些键属于库内结构标识，一律不出现在命令输出里
DROP_KEYS = ("unit_id", "topic_id", "domain_id")


def _strip_ids(obj):
    if isinstance(obj, dict):
        return {k: _strip_ids(v) for k, v in obj.items() if k not in DROP_KEYS}
    if isinstance(obj, list):
        return [_strip_ids(v) for v in obj]
    return obj


def _save_hits(hits):
    """把本轮命中落成临时序号表，供 get/unit 用序号取材。"""
    try:
        d = os.path.dirname(STATE_PATH)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump([{"n": i + 1, "id": h.get("unit_id"),
                        "title": h.get("unit_title", "")}
                       for i, h in enumerate(hits)], f, ensure_ascii=False)
    except Exception:
        pass


def _resolve_ref(ref):
    """序号 → 单元标识；非纯数字按原样透传。"""
    ref = str(ref).strip()
    if not ref.isdigit():
        return ref
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            m = json.load(f)
    except Exception:
        return None
    for x in m:
        if x.get("n") == int(ref):
            return x.get("id")
    return None


def _extract_json(text):
    """剥掉服务端的「资料片段」包装，取出其中的 JSON 主体。"""
    s = (text or "").strip()
    if s.startswith("<<<COLLECTION_TEXT") and ">>>" in s:
        s = s.split(">>>", 1)[1]
    end = s.rfind("<<<END_COLLECTION_TEXT>>>")
    if end >= 0:
        s = s[:end]
    i, j = s.find("{"), s.rfind("}")
    if i >= 0 and j > i:
        s = s[i:j + 1]
    return s.strip()


def _render_hits(payload):
    hits = payload.get("hits") or []
    lines = ["命中 %d 条（取详情用序号：get <序号>）" % len(hits)]
    for i, h in enumerate(hits, 1):
        meta = "｜".join(x for x in (h.get("era_text"), h.get("place")) if x)
        lines.append("%d. %s%s" % (i, h.get("unit_title", ""),
                                   ("（%s）" % meta) if meta else ""))
        pv = (h.get("preview") or "").strip()
        if pv:
            lines.append("   " + pv)
    if not hits:
        lines.append("（无命中，换词重试）")
    return "\n".join(lines)


def _call(tool, args):
    """带一次静默续签重试的工具调用。打印 MCP 同源文本；返回退出码。"""
    tok = load_token()
    if not tok:
        print("尚未登录。请回复\"连接瀚天知识库\"发起技能登录。")
        return 2
    auth = {"Authorization": "Bearer " + tok["access_token"],
            "Content-Type": "application/json"}
    st, body, hd = _req_json("POST", "/api/v1/" + tool, args, auth, timeout=60)
    if st == 401:
        nt = try_refresh(tok)
        if nt:
            save_token(nt)
            auth["Authorization"] = "Bearer " + nt["access_token"]
            st, body, hd = _req_json("POST", "/api/v1/" + tool, args, auth, timeout=60)
    if st == 401:
        print("登录已失效。请回复\"连接瀚天知识库\"重新登录。")
        return 2
    if st == 402:
        try:
            d = json.loads(body)
            url = (d.get("url") or d.get("recharge_url")
                   or BASE_URL + "/portal/recharge")
        except Exception:
            url = BASE_URL + "/portal/recharge"
        print()
        print("⚠️ 瀚天积分不足，本次在线查询未完成。")
        print()
        print("👉 [立即充值瀚天积分，继续查询](%s)" % url)
        print()
        print("充值完成后，请回复\"已充值\"，我会自动继续刚才的查询。")
        print()
        return 5
    if st == 429:
        try:
            wait = int(hd.get("Retry-After", 30) or 30)
        except Exception:
            wait = 30
        print("查询过于频繁，请 %d 秒后再试。" % wait)
        return 4
    if st != 200:
        print("查询失败（服务异常，错误码 %s）。请稍后重试。" % st)
        return 6
    try:
        result = json.loads(body)
        text = result["content"][0]["text"]
        if result.get("isError"):
            print("查询未成功：%s" % _strip_ids(text)[:300])
            return 6
        data = json.loads(_extract_json(text))
    except Exception:
        print("响应解析失败，请稍后重试；持续失败时按「通道不可用」改用离线知识层。")
        return 6
    if isinstance(data, dict) and "hits" in data:
        _save_hits(data["hits"])
        print(_render_hits(data))
        return 0
    print(json.dumps(_strip_ids(data), ensure_ascii=False, indent=2))
    return 0


def main():
    p = argparse.ArgumentParser(prog="h_api")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("search")
    sp.add_argument("query", nargs="+")
    sp.add_argument("--topic", dest="topic_id")
    sp.add_argument("--domain")
    sp.add_argument("--limit", type=int, default=10)

    gp = sub.add_parser("get")
    gp.add_argument("unit_id")
    gp.add_argument("--full", action="store_true")

    sub.add_parser("topics").add_argument("--domain")
    bp = sub.add_parser("topic"); bp.add_argument("topic_ref")
    up = sub.add_parser("unit"); up.add_argument("unit_id")
    gp2 = sub.add_parser("gate")
    gp2.add_argument("--draft", required=True, help="待检文稿文件路径")
    gp2.add_argument("--query")
    sub.add_parser("stats")

    a = p.parse_args()
    if a.cmd == "search":
        args = {"query": " ".join(a.query), "limit": a.limit}
        if a.topic_id:
            args["topic_id"] = a.topic_id
        if a.domain:
            args["domain"] = a.domain
        return _call("search_units", args)
    if a.cmd == "get":
        uid = _resolve_ref(a.unit_id)
        if not uid:
            print("未找到序号 %s：请先在本次会话检索，再用检索结果里的序号取材。" % a.unit_id)
            return 6
        return _call("get_unit", {"unit_id": uid,
                                  "digest": not a.full})
    if a.cmd == "unit":
        uid = _resolve_ref(a.unit_id)
        if not uid:
            print("未找到序号 %s：请先在本次会话检索，再用检索结果里的序号取材。" % a.unit_id)
            return 6
        return _call("unit_brief", {"unit_id": uid})
    if a.cmd == "topics":
        args = {}
        if a.domain:
            args["domain"] = a.domain
        return _call("list_topics", args)
    if a.cmd == "topic":
        args = {"topic_id": a.topic_ref} if a.topic_ref[:4].upper().startswith("HT-") \
            else {"topic": a.topic_ref}
        return _call("topic_brief", args)
    if a.cmd == "gate":
        try:
            with open(a.draft, "r", encoding="utf-8") as f:
                draft = f.read()
        except OSError as e:
            print("无法读取文稿：%s" % e)
            return 6
        args = {"draft": draft}
        if a.query:
            args["query"] = a.query
        return _call("gate_check", args)
    if a.cmd == "stats":
        return _call("library_stats", {})
    return 6


if __name__ == "__main__":
    sys.exit(main())
